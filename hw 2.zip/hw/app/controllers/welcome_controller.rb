class WelcomeController < ApplicationController
  def index
  	@search = $client.search('bitcoin', options = {count: 10})
  	@users = $client.user('business').description
  	@favs = $client.favorites("business", count: 10)
  end

  def about
  end

  def pages
  end

end
