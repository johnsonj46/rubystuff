module WelcomeHelper
end
