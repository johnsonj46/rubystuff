$client = Twitter::REST::Client.new do |config|
  config.consumer_key        = "12pbr8B5rhrChE4LLaUEHLANH"
  config.consumer_secret     = "eLYQNtrzhEIqxvxAFcXbxEoqiUoedC4LAorq6pWutJCppmN8h3"
  config.access_token        = "1023300452-ItUwUaOUPqNmMy7dLA4PVWPFylihMpePvjnMw2N"
  config.access_token_secret = "C4udOq9B2Twv7lOwG08kfnSh1R2SNf6jClUF5gbmH2Cy9"
end